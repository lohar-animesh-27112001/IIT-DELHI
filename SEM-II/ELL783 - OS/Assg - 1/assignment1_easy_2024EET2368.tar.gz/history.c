#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

#define MAX_HISTORY 64

struct history_entry {
    int pid;
    char name[16];
    uint mem_usage;
};

struct history_entry history[MAX_HISTORY];  // Global history array
int history_count = 0;                      // Number of stored history entries

void add_to_history(struct proc *p) {
    if (history_count < MAX_HISTORY) {
        history[history_count].pid = p->pid;
        safestrcpy(history[history_count].name, p->name, sizeof(p->name));
        history[history_count].mem_usage = p->sz;
        history_count++;
    }
}

int sys_gethistory(void) {
    for (int i = 0; i < history_count; i++) {
        cprintf("%d %s %d\n", history[i].pid, history[i].name, history[i].mem_usage);
    }
    return history_count;
}
