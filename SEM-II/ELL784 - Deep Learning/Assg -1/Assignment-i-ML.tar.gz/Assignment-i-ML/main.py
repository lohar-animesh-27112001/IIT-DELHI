import cv2
import numpy as np
import os

def PCA(motion_data, threshold=0.9):
    if motion_data.ndim < 2:
        motion_data = motion_data.reshape(-1, 1)
    mean_motion_data = np.mean(motion_data, axis=0)
    centered_data = motion_data - mean_motion_data
    covariance_matrix = np.dot(centered_data.T, centered_data) / (motion_data.shape[0] - 1)
    eigenvalues, eigenvectors = np.linalg.eig(covariance_matrix)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    variance_ratio = eigenvalues / np.sum(eigenvalues)
    variance_cumsum = np.cumsum(variance_ratio)
    key_index = np.where(variance_cumsum >= threshold)[0]
    if len(key_index) == 0:
        print("Warning: No key frames detected.")
        return [], variance_cumsum
    return key_index.tolist(), variance_cumsum

class VideoSummarization:
    def __init__(self, video_path, num_keyframes=10):
        self.video_path = video_path
        self.num_keyframes = num_keyframes
        self.frames = []
        self.keyframes = []
    
    def extract_frames(self):
        cap = cv2.VideoCapture(self.video_path)
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            self.frames.append(cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY))
        cap.release()
    
    def compute_keyframes(self):
        diff_frames = [np.abs(self.frames[i+1] - self.frames[i]).sum() for i in range(len(self.frames)-1)]
        keyframe_indices = np.argsort(diff_frames)[-self.num_keyframes:]
        keyframe_indices.sort()
        self.keyframes = [self.frames[i] for i in keyframe_indices]
    
    def save_keyframes(self, output_dir="keyframes"):
        os.makedirs(output_dir, exist_ok=True)
        for idx, frame in enumerate(self.keyframes):
            cv2.imwrite(f"{output_dir}/keyframe_{idx}.png", frame)
    
    def summarize(self):
        self.extract_frames()
        self.compute_keyframes()
        self.save_keyframes()

class BackgroundSubtraction:
    def __init__(self, frames, num_gaussians=3, learning_rate=0.01):
        self.frames = frames
        self.num_gaussians = num_gaussians
        self.learning_rate = learning_rate
        self.background_model = None
    
    def initialize_model(self, shape):
        self.background_model = [
            {
                'mean': np.random.rand(*shape) * 255,
                'variance': np.ones(shape) * 500,
                'weight': np.ones(shape) / self.num_gaussians
            } for _ in range(self.num_gaussians)
        ]
    
    def update_model(self, frame):
        for i in range(self.num_gaussians):
            match = np.abs(frame - self.background_model[i]['mean']) < 2.5 * np.sqrt(self.background_model[i]['variance'])
            self.background_model[i]['weight'] = (1 - self.learning_rate) * self.background_model[i]['weight'] + self.learning_rate * match
            self.background_model[i]['mean'][match] = (1 - self.learning_rate) * self.background_model[i]['mean'][match] + self.learning_rate * frame[match]
            self.background_model[i]['variance'][match] = (1 - self.learning_rate) * self.background_model[i]['variance'][match] + self.learning_rate * (frame[match] - self.background_model[i]['mean'][match])**2
    
    def get_foreground_mask(self, frame):
        match_scores = np.array([np.abs(frame - g['mean']) < 2.5 * np.sqrt(g['variance']) for g in self.background_model])
        background_mask = np.any(match_scores, axis=0)
        return np.uint8(~background_mask * 255)
    
    def process_frames(self):
        shape = self.frames[0].shape
        self.initialize_model(shape)
        fg_masks = []
        for frame in self.frames:
            self.update_model(frame)
            fg_masks.append(self.get_foreground_mask(frame))
        return fg_masks

def background_subtraction(video_path, output_dir, learning_rate=0.008, detect_shadows=True):
    capture_video = cv2.VideoCapture(video_path)
    if not capture_video.isOpened():
        raise Exception("Error! Can't open the video file")
    bg_subtractor = cv2.createBackgroundSubtractorMOG2(history=100, varThreshold=10, detectShadows=detect_shadows)
    os.makedirs(output_dir, exist_ok=True)
    frame_width = int(capture_video.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(capture_video.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = capture_video.get(cv2.CAP_PROP_FPS) or 20.0
    foreground_video = cv2.VideoWriter(
        os.path.join(output_dir, "foreground.avi"),
        cv2.VideoWriter_fourcc(*'XVID'),
        fps,
        (frame_width, frame_height),
    )
    background_video = cv2.VideoWriter(
        os.path.join(output_dir, "background.avi"),
        cv2.VideoWriter_fourcc(*'XVID'),
        fps,
        (frame_width, frame_height),
    )
    while True:
        ret, frame = capture_video.read()
        if not ret:
            break
        foreground_mask = bg_subtractor.apply(frame, learningRate=learning_rate)
        background_frame = bg_subtractor.getBackgroundImage()
        foreground_frame = cv2.bitwise_and(frame, frame, mask=foreground_mask)
        if background_frame is not None:
            background_video.write(background_frame)
        foreground_video.write(foreground_frame)
    capture_video.release()
    foreground_video.release()
    background_video.release()
    print(f"Foreground and Background videos saved to {output_dir}")
    return output_dir

if __name__ == "__main__":
    video_path = "./umcp.mp4"
    output_dir = "./output"

    # Part 1: Video summarization
    summarizer = VideoSummarization(video_path, num_keyframes=10)
    summarizer.summarize()
    frames = summarizer.keyframes
    
    # Part 2: Background subtraction
    bg_subtractor = BackgroundSubtraction(frames)
    fg_masks = bg_subtractor.process_frames()
    background_subtraction(video_path, output_dir)
    
    for idx, mask in enumerate(fg_masks):
        cv2.imwrite(f"foreground_mask_{idx}.png", mask)